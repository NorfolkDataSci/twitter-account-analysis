#internal function (not exported)
words <-
function(x){as.vector(unlist(strsplit(x, " ")))}
