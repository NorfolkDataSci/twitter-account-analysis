<p><img src="https://dl.dropbox.com/u/61803503/qdapicon.png" alt="qdapicon"/><br/>
<a href="https://github.com/trinker/qdap">qdapDictionaries</a> is an R package that contains the dictionaries and word lists for use with the qdap package.</p>

<p>Download the development version of qdapDictionaries <a href="https://github.com/trinker/qdapDictionaries/">here</a> 